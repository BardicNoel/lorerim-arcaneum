import { type Config } from "tailwindcss";

const config: Config = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}"
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        skyrim: {
          gold: "#d4af37",
          dark: "#1e1e1e"
        }
      },
      fontFamily: {
        cinzel: ["Cinzel", "serif"],
        crimson: ["Crimson Text", "serif"]
      },
      borderRadius: {
        lg: "var(--radius)"
      }
    }
  },
  plugins: [require("tailwindcss-animate")]
});

export default config;
